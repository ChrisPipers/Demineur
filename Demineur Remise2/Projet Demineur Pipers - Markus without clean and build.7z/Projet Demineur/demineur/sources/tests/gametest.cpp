/*
#define CATCH_CONFIG_MAIN

#include "headers/tests/test.h"
#include "headers/tests/catch.hpp"
#include "headers/model/game.h"

#include <iomanip>

using namespace model;
using namespace std;

TEST_CASE("test1 the constructor ")
{
    Game game = Game();

    SECTION("")
    {

    }
}
*/
