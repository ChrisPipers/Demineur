#include "headers/model/game.h"

#include <string>
//#ifndef RUNTEST   //décomenter pour lancer les tests
//#define CATCH_CONFIG_MAIN

using namespace std;
using namespace model;

int main()
{
    cout << " ************ DEMINEUR ************ " << endl;
    Game game = Game();

}

//#endif    //décomenter pour lancer les tests
