#ifndef TEST
#define TEST

// Commenter - Décomenter #define RUNTEST
// Sur QtCreator : possibilité de devoir redémarrer.

//#define CATCH_CONFIG_MAIN


#endif // TEST

